package Barath.com.Let.s.Go.Cab.service;

import Barath.com.Let.s.Go.Cab.dto.CustomerRegisterRequest;
import Barath.com.Let.s.Go.Cab.model.Customer;
import Barath.com.Let.s.Go.Cab.repository.CustomerRepository;
import Barath.com.Let.s.Go.Cab.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtil jwtUtil;

    // Register a new customer
    public Customer registerCustomer(Customer customer) {
        if (customerRepository.findByEmail(customer.getEmail()).isPresent()) {
            throw new RuntimeException("Customer already exists with this email");
        }

        // Encode password before saving
        customer.setPassword(passwordEncoder.encode(customer.getPassword()));
        return customerRepository.save(customer);
    }

    // Login and return JWT token
    public String loginCustomer(String email, String password) {
        Customer customer = customerRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Customer not found"));

        if (!passwordEncoder.matches(password, customer.getPassword())) {
            throw new RuntimeException("Invalid credentials");
        }

        return jwtUtil.generateToken(customer.getEmail(), "CUSTOMER");
    }

    // Fetch customer by email (optional helper)
    public Optional<Customer> findByEmail(String email) {
        return customerRepository.findByEmail(email);
    }


}
