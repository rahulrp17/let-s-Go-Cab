package Barath.com.Let.s.Go.Cab.controller;

import Barath.com.Let.s.Go.Cab.model.Customer;
import Barath.com.Let.s.Go.Cab.service.CustomerService;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/customer")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    // POST: Register a new customer
    @PostMapping("/register")
    public ResponseEntity<Customer> register(@RequestBody Customer customer) {
        Customer registeredCustomer = customerService.registerCustomer(customer);
        return ResponseEntity.ok(registeredCustomer);
    }

    // POST: Login and return JWT token
    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody LoginRequest request) {
        String token = customerService.loginCustomer(request.getEmail(), request.getPassword());
        return ResponseEntity.ok(token);
    }

    // DTO class for login request
    @Data
    public static class LoginRequest {
        private String email;
        private String password;
    }
}
